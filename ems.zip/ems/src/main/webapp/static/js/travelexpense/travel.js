$( document ).ready(function() {
    console.log( "ready!" );
    
    var vm = new Vue({
		  el: '#app',
		  data: {
		    traveldata: ''
		  }
		});
    
    $("#saveTravelBtn").click(function(){
    	console.log("Clicked!");
    	console.log( "ready! serialize : "+ $("#travelFormId").serialize() );
    	console.log( "ready! Stringify: "+ JSON.stringify($("#travelFormId").serialize()) );
    	console.log( "ready! Calling Ajax" );
     	$.ajax({
			type : "POST",
 			url : "/Spring4MVCApacheTiles3Example/te/travel",
			data : $("#travelFormId").serialize(),
			dataType : 'json',
			timeout : 100000,
			success : function(data) {
				console.log("SUCCESS: ", JSON.stringify(data));
				vm.traveldata = data;
				$("#travelFormId")[0].reset();
			},
			error : function(e) {
				console.log("ERROR: ", e);
				
			},
			done : function(e) {
				console.log("DONE");
			}
		});
    	
    });
    
    
    
    //Leaving Date picker
    $('#leavingDate').datepicker({
      autoclose: true,
      format: "dd-mm-yyyy",
      todayHighlight:true
    });

    //Leaving Date picker
    $('#arrivingDate').datepicker({
    	autoclose: true,
    	format: "dd-mm-yyyy",
        todayHighlight:true

    });
    
});