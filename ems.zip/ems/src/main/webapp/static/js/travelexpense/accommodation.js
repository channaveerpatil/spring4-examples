$( document ).ready(function() {
    console.log( "ready!" );
    
    
    $("#accommodationBtn").click(function(){
    	console.log("accommodationId Clicked!");
    	console.log( "ready! serialize : "+ $("#accommodationFormId").serialize() );
    	console.log( "ready! Stringify: "+ JSON.stringify($("#accommodationFormId").serialize()) );

    	console.log( "ready! Calling Ajax");
    	var data = {leavingFrom : "aa", goingTo : "ss"}
    	$.ajax({
			type : "POST",
 			url : "/Spring4MVCApacheTiles3Example/te/accommodation",
			data : $("#accommodationFormId").serialize(),
			dataType : 'json',
			timeout : 100000,
			success : function(data) {
				console.log("SUCCESS: ", data);
				
			},
			error : function(e) {
				console.log("ERROR: ", e);
				
			},
			done : function(e) {
				console.log("DONE");
				
			}
		});
    	
    });
    
    
});