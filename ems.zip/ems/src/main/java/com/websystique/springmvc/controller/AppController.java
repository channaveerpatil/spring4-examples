package com.websystique.springmvc.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.fasterxml.jackson.databind.util.JSONPObject;



@Controller
@RequestMapping("/te")
@SessionAttributes({"travelExpense"})
public class AppController {

	@RequestMapping(value = { "/home"}, method = RequestMethod.GET)
	public String homePage(ModelMap model) {
		model.addAttribute("home", "homeMenu");
		return "home";
	}

	@RequestMapping(value = { "/products"}, method = RequestMethod.GET)
	public String productsPage(ModelMap model) {
		model.addAttribute("product", "productMenu");
		return "products";
	}

	@RequestMapping(value = { "/contactus"}, method = RequestMethod.GET)
	public String contactUsPage(ModelMap model) {
		return "contactus";
	}

	@RequestMapping(value = {"/teHome"}, method = RequestMethod.GET)
	public String travelExp(ModelMap model, SessionStatus session ) {
		model.addAttribute("travelex", new Travel());
		model.addAttribute("accommodation", new Accommodation());
		session.setComplete();
		return "teHome";
	}

 	@RequestMapping(value = {"/travel"}, method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public TravelExpense saveTravel(ModelMap map, @ModelAttribute("travelex") Travel travel, BindingResult results) {
		
 		List<Travel> travels = null;
 		float total = 0;
  		TravelExpense travelExpense = new TravelExpense();
  		ExpenseTotal expenseTotal = new ExpenseTotal();
 		TravelExpense teSession = (TravelExpense) map.get("travelExpense");
  		
		if(teSession != null) {
			travels = teSession.getTravel();
			travels.add(travel);
   		} else {
   			travels = new ArrayList<Travel>();
   			travels.add(travel);
 		}
 		// travels.stream().forEach(x ->  {double total = 0; total = total + x.getAmount(); });
 		for (Travel t : travels) {
			total = total + t.getAmount();
		}
 		expenseTotal.setTravelotal(total);
 		travelExpense.setExpenseTotal(expenseTotal);
 		travelExpense.setTravel(travels);
		map.addAttribute("travelExpense", travelExpense);
		
		return travelExpense;
	}

	@RequestMapping(value = {"/accommodation"}, method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Accommodation saveAccommodation(ModelMap model, @ModelAttribute("accommodation") Accommodation accommodation, BindingResult results) {
		System.out.println("Travel Leaving From : " +accommodation.getHotelName());

		return accommodation;
	}


}