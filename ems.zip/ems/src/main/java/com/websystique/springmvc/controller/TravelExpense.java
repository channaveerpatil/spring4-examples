package com.websystique.springmvc.controller;

import java.util.List;

public class TravelExpense {

	private List<Travel> travel;
	
	private List<Accommodation> accommodation;
	
	private ExpenseTotal expenseTotal;

	public List<Travel> getTravel() {
		return travel;
	}

	public void setTravel(List<Travel> travel) {
		this.travel = travel;
	}

	public List<Accommodation> getAccommodation() {
		return accommodation;
	}

	public void setAccommodation(List<Accommodation> accommodation) {
		this.accommodation = accommodation;
	}

	public ExpenseTotal getExpenseTotal() {
		return expenseTotal;
	}

	public void setExpenseTotal(ExpenseTotal expenseTotal) {
		this.expenseTotal = expenseTotal;
	}
 
}
