package com.websystique.springmvc.controller;

public class ExpenseTotal {

	float travelotal;
	
	float accomodationTotal;

	public float getTravelotal() {
		return travelotal;
	}

	public void setTravelotal(float travelotal) {
		this.travelotal = travelotal;
	}

	public float getAccomodationTotal() {
		return accomodationTotal;
	}

	public void setAccomodationTotal(float accomodationTotal) {
		this.accomodationTotal = accomodationTotal;
	}

	
	
}
