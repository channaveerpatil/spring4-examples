package com.websystique.springmvc.controller;

import java.util.Date;

public class Travel {
	
	private String leavingFrom;
	
	private String goingTo;
	
	private String travelType;
	
	private float amount;
	
	private String leavingDate;
	
	private String arrivingDate;
	
	private float total;

	public String getLeavingFrom() {
		return leavingFrom;
	}

	public void setLeavingFrom(String leavingFrom) {
		this.leavingFrom = leavingFrom;
	}

	public String getGoingTo() {
		return goingTo;
	}
	
	public void setGoingTo(String goingTo) {
		this.goingTo = goingTo;
	}

	public String getTravelType() {
		return travelType;
	}

	public void setTravelType(String travelType) {
		this.travelType = travelType;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getLeavingDate() {
		return leavingDate;
	}

	public void setLeavingDate(String leavingDate) {
		this.leavingDate = leavingDate;
	}

	public String getArrivingDate() {
		return arrivingDate;
	}

	public void setArrivingDate(String arrivingDate) {
		this.arrivingDate = arrivingDate;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

}
